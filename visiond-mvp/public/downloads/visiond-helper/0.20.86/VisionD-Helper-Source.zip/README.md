# VisionD Browser Launcher

## Separate device-pairing protocol (v0.20.86)

The verified downloaded Setup registers `visiond-helper-pair` only for the same-browser device-pairing intent. Its URI carries one exact version-4 intent UUID; the native Helper still displays the account comparison and requires the Windows user to approve before staging. The existing `visiond-profile` association remains registered to the same owned versioned executable for channel launches. The installer rejects a pre-existing foreign pairing association before changing files or registry, and rollback restores the previous owned image, service and registration. Removing the installed v0.20.86 Helper removes only its verified associations. A new scheme avoids the old association state observed on this Windows machine; actual browser dispatch still requires a user-approved live check.

## Versioned installed image (v0.20.85)

The owned installer now places the executing Helper at `VisionDBrowserLauncher-0.20.85.exe` and registers that exact path for the local service and browser protocol. A verified legacy `VisionDBrowserLauncher.exe` is stopped and moved aside during installation, with its file, owner marker, and registry values restored if installation fails. The encrypted Transport identity and Chrome Profiles are not moved. This avoids a new protocol process mapping the old executable image from the reused path; the local user still confirms the browser account code and replacement in the existing flow.

Use the verified downloaded `VisionD-Helper-Setup.exe` for this upgrade. The bundled historical PowerShell install/uninstall scripts still target the old unversioned path and are not the upgrade path for v0.20.85 or later.

## On-screen pairing diagnostic (v0.20.84)

If pairing fails, the installed Helper displays only the last fixed phase, a fixed error category and, if available, a numeric HTTP status. This remains visible when its private diagnostic file cannot be written. The window never includes an exception message, account code, intent, Helper ID, URL, response body or secret. A single user-approved attempt is still needed to identify the live failure; this version does not alter pairing authorization.

## Local pairing diagnostic (v0.20.83)

The installed Helper records only fixed pairing phase names and a numeric HTTP status in its ACL-protected `pair-diagnostic.txt` beside `helper.dpapi`. It overwrites the previous attempt and records no account code, intent, Helper ID, URL, request body, secret, or profile data. This identifies whether a failed pairing stopped before config load, before the stage request, at a stage HTTP response, or after an accepted stage. A failure does not alter the Helper identity or pairing rules.

## Revoked local identity recovery (v0.20.82)

After the user confirms the account code in the installed Helper, an exact `LAUNCHER_HELPER_REVOKED` response for its current ID, owner, port, secret, user and intent starts a new encrypted local candidate without a second native dialog. The original identity and profiles stay unchanged until the browser user compares the new code, confirms the exact same-owner helper being replaced, and the native client receives signed confirmation of that replacement. Other errors do not rotate identity. An active helper attached to an unconfirmed intent is reported as unverified to the wizard, so it cannot be presented as a completed new local pairing.

## Downloaded Setup startup (v0.20.81)

Opening the downloaded Setup executable and approving Windows now runs the existing owned install/update transaction once after the installer window appears. It starts and verifies the owned Helper service and registers the URI handler; no separate Install button click is needed. Opening the already-installed executable does not reinstall it. The Install button remains available for an explicit retry, including when an earlier Setup window holds the installer mutex. Existing exact-owner checks, foreign-process protection, rollback, degraded-port recovery and profile preservation remain in `Install()`. Pairing and port repair still require their separate human approvals. A browser download alone cannot run the executable.

## Same-tab Next pairing (v0.20.79)

The authenticated setup page creates a five-minute, session-bound pair intent and invokes the installed Helper with only its random intent UUID. The Helper reads a short, non-authorizing account comparison code from the fixed VisionD HTTPS origin, asks the Windows user to compare it with the original tab and confirm this device, stages its own random twelve-character code, and displays that code locally. The original browser tab polls only its own intent, prepares the exact helper and shows the code for human comparison. Pair confirmation still needs an explicit checkbox and click, the original live session/VX grant, nonce, owner and exact replacement checks; the intent is consumed in the same transaction. No pairing secret, browser cookie, account email or profile content passes through the custom URI, local HTTP listener or browser storage. A lost stage response may return the same staged code to the same native helper and intent. Existing manual code entry remains available under advanced setup.

Migration `0143_launcher_pair_intents.sql` must be applied before serving the new page or installing this release. The existing local listener still accepts only launch commands; no pairing endpoint was added there. The executable is unsigned, as indicated by the release manifest; Windows and installer approval remain explicit.

## Compatibility enforcement (v0.20.78)

Every claim now sends the exact HMAC-bound capability launcher/0.20.78;no-first-run=1. Legacy helpers74–77 send an empty claim and receive failed/HELPER_UPDATE_REQUIRED without any ticket or Chrome launch. Install the current downloaded Setup to update the executing service; downloading alone is not installation. Normal owned upgrade preserves DPAPI pairing, port and Profiles. Migration0103 must precede server deployment. Native post-upgrade window-count verification remains necessary.

## Single useful startup tab (v0.20.77)

The owned launch adds fixed `--no-first-run` before `--new-window` and its single URL. This skips Chrome's first-run onboarding in the isolated profile without copying cookies or changing global/default-browser settings. A disposable Chrome152 local fixture produced one useful tab for clean and established profiles; without this flag clean profiles stopped at chrome://intro. Existing user tabs are not closed or deleted, and provider consent remains user-controlled. Run the explicitly opt-in `single-tab-probe.mjs --gui-probe` for local non-provider tab-count verification; it creates only disposable profiles.

## Durable occupied-port recovery (retained)

An owned upgrade may retain the verified new executable and owned registration in a **degraded/not-ready** state only when its child exits48 (bind-address-in-use), the configured literal loopback port remains occupied, and no owned service remains. It never kills or takes over the port owner. Exit0/2/32 and unproved failures remain failures/rollback, with exit-specific diagnostics. Readiness requires exactly the configured port under the returned process PID, not any listener.

Choose the explicit **ซ่อมพอร์ต / ยืนยันเครื่องใหม่** action. A distinct durable `helper.repair.dpapi` candidate contains a new key/identity, OS-allocated exclusive-tested ephemeral port, exact prior helper ID and prior config hash. The old active configuration is preserved before human confirmation in the already-open authenticated Chrome page. Migration0100 adds `replaces_helper_id`: prepare/final confirmation require the exact old active helper/current owner; signed pair-state returns the committed replacement proof. This is a two-phase process, not a transaction across Windows and the server.

On retry, signed status for the SAME candidate is checked before staging. After server activation/revocation, exact prior-config hash guards atomic File.Replace; a crash before replacement resumes the candidate, never rolls back to the revoked key. After promotion a durable config flag requires retrying the same key/port until verified startup, without silently creating another identity. Port probing is not reservation across human confirmation: a later collision produces an explicit recoverable failure, never readiness. No Chrome restart, foreign-process kill, default-browser launch, cookie transfer, profile deletion or automatic confirmation occurs. Deploy additive0100 before matching code; old0100-null pairing behavior remains compatible.

Pairing boundary v0.20.75: native validates the pair-stage response's pair_id and opens clean `/launcher-pair#id=...` without a canonical HTML redirect. The page accepts up to eight validated distinct hash arrivals within five minutes, aborts prior prepare work and ignores stale responses. Duplicate/invalid hashes cannot replace approval; no hash replaces an in-flight confirmation or completed page. Expired/conflicting requests require a new explicit Helper request. Identifiers remain non-authorizing fragment hints; auth/session/VX/nonce and human code-match confirmation are unchanged. This hardening does not claim a proved cause for the previously observed external Chrome fragment absence; real pairing verification remains required.

This Windows-only, per-user helper opens fixed destinations in isolated Chrome directories. Normal v72 transport does not depend on Chrome custom-scheme discovery. View opens TikTok Login without issuing OAuth; Connect/new uses official consent. The helper never reads, copies, exports or logs cookies.

## Paired local transport (v0.20.72)

Install starts an owned singleton loopback listener on a random stable port, and registers that exact executable under the current user's Run key. The GUI-subsystem executable does not create a startup console. Initial setup is a separate, explicit `VisionDBrowserLauncher.exe --pair` action: enter the fresh twelve-character code from its local message in the already authenticated `/launcher-setup` page, check the match box, then click `ยืนยันผูกตัวช่วยเครื่องนี้`. Never approve an unsolicited pairing link. Installation and tests do not open pairing/provider windows automatically.

The helper generates a 256-bit shared secret, stores it using DPAPI CurrentUser with a restricted Transport-directory ACL, and sends it only to the fixed VisionD HTTPS endpoint. The server encrypts the stored key with owner/helper/version-associated data. Pairing requires an authenticated original session and explicit one-use confirmation. `--pair-replace` stages a separate DPAPI candidate, names/revokes the exact old helper on confirmation, and promotes the candidate only after an authenticated result; cancellation/network loss preserves the old local configuration and rerunning resumes the same candidate.

A genuine Analyzer click synchronously opens a harmless same-origin `noopener,noreferrer` bootstrap, then the Analyzer alone performs the authorized command POST. The bootstrap only reads an already-created command belonging to the exact current user/session and its authoritative paired port; standalone links cannot create commands. The browser handles only a non-capability command UUID, never the native ticket or helper secret. The bootstrap navigates to `http://127.0.0.1:<paired port>/launch?command_id=<UUID>`. All fetch headers and bodies have abort/deadline guards; bootstrap resolution stops after at most eight attempts within 25 seconds. The listener claims authoritative profile fields over TLS with purpose-separated nonce/HMAC authentication. A fake local listener can see an ID or cause timeout, but cannot claim a ticket or forge server status. Same-Windows-user full compromise is outside this boundary; DPAPI is not executable attestation.

Before Process.Start, the helper durably records an ambiguous journal entry. Repeated requests report the saved outcome without launching twice. The backend rechecks the original live session, grants, immutable binding, head and expiry before returning any ticket. Main status polling is same-origin, indexed and bounded to eight attempts (about 24 seconds), then manual/focus refresh only. `process_started` means the helper started Chrome, not that login or API consent succeeded. Cancellation serializes with claim and leaves a 24-hour bounded-cleanup tombstone so a slow bootstrap cannot resurrect a cancelled request. Claimed/ambiguous live requests cannot be cancelled into a duplicate launch. Temporary tabs attempt self-close; if Chrome refuses, they explain that the tab may be closed, never closing the provider profile.

## Direct API handoff (v0.20.72)

The current handoff form is `visiond-profile://open?mode=handoff&profile_kind=<slot|channel>&slot_id=<UUID>&id=<UUID>&ticket=<64 lowercase hex>`. The server derives the exact directory kind and identifier. The helper reconstructs a fixed HTTPS fragment landing, which immediately clears the fragment and redeems by same-origin POST with the same kind. No website session is transferred. Hashed capability/state/nonce, original session/grant checks and the host-only HttpOnly Secure nonce remain enforced at callback and final atomic persistence. The old kindless handoff parser remains compatible with slot profiles only.

Click Connect to start official consent directly. Bound channels reuse their stored immutable directory kind; unbound existing channels use their deterministic `channel-UUID` directory. A requested Shop connection first verifies Login Kit if necessary, then rotates the same guarded flow to new Shop state/nonce inside the binding transaction and redirects to official Shop consent. Original expiry/session/grant/head remain unchanged. Shop uses its own identity namespace. `+ ช่องใหม่` starts real Login Kit consent in a server-generated fresh slot; there is no intermediate dialog, copy step or UUID input.

Install migrations 0095–0099 in order and upgrade/pair the owned helper before releasing this code. Focus/manual refresh checks only the selected outstanding request (or current new-channel request). Multiple profiles retain separate pending requests; repeated same-channel clicks do not supersede them. Returned channels are selected only while the original UI revision remains current. The scheme parser below remains a strict legacy compatibility surface, not the normal website transport.

## Safety boundary

- The custom scheme accepts exactly one of these canonical forms:
  - `visiond-profile://open?mode=existing&channel_id=<UUID>` (legacy view)
  - `visiond-profile://open?mode=existing&channel_id=<UUID>&intent=<view|tiktok|shop>` (legacy unbound channel)
  - `visiond-profile://open?mode=existing&channel_id=<UUID>&slot_id=<UUID>&intent=<view|tiktok|shop>` (authoritatively bound profile)
  - `visiond-profile://open?mode=new&slot_id=<UUID>`
  - `visiond-profile://open?mode=handoff&slot_id=<UUID>&id=<UUID>&ticket=<64 lowercase hex>`
  - `visiond-profile://open?mode=handoff&profile_kind=<slot|channel>&slot_id=<UUID>&id=<UUID>&ticket=<64 lowercase hex>`
- Windows Shell normalizes those forms to `visiond-profile://open/?...`; the helper accepts that one empty root slash as equivalent, but rejects every other path or extra slash.
- The helper rejects alternate hosts, paths, query order, duplicate/unknown parameters, percent-encoding, fragments, control characters, empty UUIDs and non-UUID identifiers.
- The target origin/path and Chrome switches are compiled into the helper. Callers cannot supply a URL, executable, filesystem path, browser flag, OAuth state/code/token or command.
- Legacy channels without a saved binding reuse `Profiles/channel-<UUID>`. A fresh channel starts in `Profiles/slot-<UUID>`; after a verified Login Kit callback, VisionD returns the same owner-scoped slot with that channel and all later opens reuse the slot directory. The native helper never decides or changes that binding.
- New, pending and view actions open TikTok Login without connecting an API or binding a channel. The main page uses authenticated handoffs for API consent. Historical explicit `tiktok`/`shop` native intents retain their fixed VisionD target only for compatibility; main-page consent no longer dispatches these old intents.

## Install and uninstall

End users: visit `https://visiondonline.com/launcher-setup.html`, validate the version/SHA256 manifest, download the frozen **VisionD-Helper-Setup.exe**, and double-click it. This is a Windows x64 .NET Framework 4.8 application. Choose Install/Update explicitly, then Pair explicitly; neither runs just by opening Setup. The source ZIP includes the repository MIT LICENSE. These release bytes are unsigned: Windows or organization policy can block them. Do not disable security settings to proceed. No byte-reproducible-build claim is made.

The GUI installer checks exact prior ownership, backs up the old owned binary, verifies initialization and the new process's single loopback listener, and restores the old binary/service on failure. Registry rollback restores only values written by this attempt when they still match; unrelated values are preserved. Opening the already-installed executable never overwrites its executing image: Install checks/starts its service. To update the bytes, use the new downloaded Setup. Uninstall from the installed executable disables owned startup/protocol/service but retains the executing file; close it and uninstall using the downloaded Setup to remove that file. Profiles and Transport are always retained.

The Analyzer uses the authenticated owner list (24 rows plus a LIMIT25 sentinel): matching browser preference wins; a unique complete first page can recover a helper without re-pairing; multiple helpers require explicit bounded selection. Manual refresh deduplicates a fresh lookup and invalidates a negative result. If readiness is unknown, its first click checks without opening a tab; the next explicit click may proceed. An unpaired/error state shows Setup and creates no command or wait tab. An active server row alone never proves a service is running on this machine. Pairing authenticates first and offers login/retry/expiry recovery; the current code-entry flow keeps the enrollment code only in memory, never URL/storage/logs. The legacy eight-character ID-based page remains isolated from new twelve-character attempts.

Maintainers can build frozen public bytes with `node tools/browser-launcher/build-release.mjs`; it compiles and archives without executing Setup. The following source-install scripts remain maintenance alternatives, not required user steps.

Run `install.ps1` as the current user. It compiles with the bundled Windows .NET Framework C# compiler and registers `visiond-profile` under `HKCU` only if the scheme is absent or already owned by this exact install. No download or administrator access is required.

Run `uninstall.ps1` to stop only the verified owned listener and remove its exact owned Run entry, protocol registration, executable and marker. It preserves Profiles and DPAPI Transport configuration for reinstall. It never stops unrelated processes or deletes browser data. Replacing the paired helper explicitly revokes its previous backend key.

Old `?connect=` links still resolve the exact owned channel and display a notice to click its Connect button. Page-load hints do not authorize an unsolicited new flow. Optional View opens TikTok Login in the stored directory kind. Existing pending and legacy directories are preserved; no data is copied, deleted or silently assigned to a channel.

Deployment is migration-first: install `0095_tiktok_browser_profile_bindings.sql`, `0096_tiktok_oauth_handoffs.sql`, `0097_tiktok_direct_profile_login.sql`, then `0098_browser_launcher_transport.sql` and index-only `0099_browser_launcher_pair_code.sql` before serving matching website code. Migrations use tracking and must not be applied on requests. Release remains gated on actual already-running Chrome popup/loopback behavior, owned install/listener verification and explicit human pairing; synthetic tests alone do not prove delivery.

Windows/browser protocol prompts do not reliably prove which website initiated a valid custom-scheme request. Close unexpected prompts. Valid requests only open fixed destinations in app-owned profiles. The fixed `--no-default-browser-check` launch flag suppresses Chromium's default-browser check without changing the system default or browser settings; actual dialog disappearance still requires runtime verification. The separate fixed --no-first-run flag skips Chrome onboarding only; provider login and consent are never suppressed.

## Same-browser pairing (v0.20.75)

The current authenticated setup page uses `visiond-helper-pair://setup/pair?intent=<uuid>` with an exact short-lived intent UUID. The historical `visiond-profile://setup/pair` verb remains native-compatible; neither setup form can launch a profile. Native requires local approval, stages a fresh 48-bit CSPRNG code through fixed TLS, and displays it without opening HTTP(S), Edge, or any browser. If Windows does not discover the scheme, manually open the verified installed Helper and choose Pair. Scheme dispatch is not guaranteed or treated as a receipt.

Enter the code in the original Chrome page, compare, and explicitly confirm. Exact indexed LIMIT2 lookup rejects collisions; IP/account limits bound guesses; prepare/final CAS bind code, expiry, original session, nonce and current VX rights. Rotation clears prior prepared ownership and nonce atomically; same-attempt retry does not extend expiry; active helpers are never demoted. Replacement retains the existing DPAPI candidate/promotion and exact prior-helper revocation safeguards. No native caller-origin identity is assumed.
