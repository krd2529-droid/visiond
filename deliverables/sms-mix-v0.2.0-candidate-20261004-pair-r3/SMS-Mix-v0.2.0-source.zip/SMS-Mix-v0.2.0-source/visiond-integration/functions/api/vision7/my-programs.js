import { json } from '../../_lib.js';
import { ensureDatabase } from '../../_schema.js';
import { ensureVision7Schema } from '../../_vision7_schema.js';
import { requireVision7User as requireUser } from '../../_vision7_auth.js';
import { maskedLicense, refreshLicenseExpiry } from '../../_vision7.js';
import { decryptVision7Key, vision7LicenseEncryptionConfigured } from '../../_vision7_license_crypto.js';

export async function onRequestGet(ctx) {
  await ensureDatabase(ctx.env);
  await ensureVision7Schema(ctx.env);
  const a = await requireUser(ctx);
  if (a.error) return a.error;
  const rows = await ctx.env.DB.prepare(`SELECT l.*,p.code,p.platform_type,p.current_version,p.minimum_version,p.force_update,p.requires_online,
    COALESCE(x.title,px.title) title,COALESCE(x.cover_url,px.cover_url) cover_url,q.name plan_name,
    b.device_name smsmix_device_name,substr(b.device_hash,-8) smsmix_hash_suffix,
    b.generation smsmix_generation,b.activated_at smsmix_activated_at
    FROM vision7_licenses l JOIN vision7_programs p ON p.id=l.program_id
    LEFT JOIN products x ON x.id=p.product_id LEFT JOIN vision7_plans q ON q.id=l.plan_id
    LEFT JOIN products px ON px.id=q.product_id
    LEFT JOIN vision7_smsmix_bindings b ON p.code='sms-mix' AND b.license_id=l.id
    WHERE l.user_id=? ORDER BY l.created_at DESC`).bind(a.user.id).all();
  const items = [];
  for (let row of rows.results || []) {
    row = await refreshLicenseExpiry(ctx.env, row);
    const d = row.code === 'sms-mix' ? { results: row.smsmix_hash_suffix ? [{
      id: null, device_name: row.smsmix_device_name, platform: 'Android',
      hash_suffix: row.smsmix_hash_suffix, generation: row.smsmix_generation,
      activated_at: row.smsmix_activated_at
    }] : [] } : await ctx.env.DB.prepare(`SELECT id,device_name,platform,app_version,activated_at,last_seen_at
      FROM vision7_license_devices WHERE license_id=? AND revoked_at IS NULL ORDER BY last_seen_at DESC`).bind(row.id).all();
    const release = await ctx.env.DB.prepare(`SELECT id,version,minimum_version,mandatory,file_name,file_size,sha256,release_notes,published_at
      FROM vision7_releases WHERE program_id=? AND status='published' ORDER BY published_at DESC,id DESC LIMIT 1`).bind(row.program_id).first();
    let key = null;
    if (row.key_ciphertext && vision7LicenseEncryptionConfigured(ctx.env)) {
      try { key = await decryptVision7Key(ctx.env, row.key_ciphertext); } catch {}
    }
    items.push({ ...row, key, key_masked: maskedLicense(row), key_ciphertext: undefined,
      key_hash: undefined, devices: d.results || [], release: release ? {
        ...release, download_url: `/api/vision7/releases/${release.id}/download`
      } : null });
  }
  return json({ items, encryption_ready: vision7LicenseEncryptionConfigured(ctx.env) });
}
