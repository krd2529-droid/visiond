const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const size=n=>`${Math.max(1,Math.ceil(Number(n||0)/1024/1024))} MB`;
async function load(){
  const r=await fetch('/api/vision7/my-programs'),d=await r.json();
  if(r.status===401){location.href='/login.html?next=/my-programs.html';return}
  document.querySelector('#items').innerHTML=(d.items||[]).map(x=>{
    const active=['active','trial'].includes(x.status),release=x.release;
    const devices=x.devices.map(y=>`<p>${esc(y.device_name||y.platform||'อุปกรณ์')}${x.code==='sms-mix'?` · รหัสท้าย ${esc(y.hash_suffix||'')} · ผูกเมื่อ ${esc(y.activated_at||'')}`:` <button class="danger" data-id="${y.id}">ปิดเครื่องนี้</button>`}</p>`).join('')||'<p class="muted">ยังไม่มีเครื่องที่เปิดใช้งาน</p>';
    return `<article class="card"><h2>${esc(x.title||x.code)}</h2><p><span class="status">${esc(x.status)}</span> · ${esc(x.plan_name||'ทดลอง')}</p><p>คีย์ <code>${esc(x.key||x.key_masked)}</code>${x.key?` <button class="copy" data-key="${esc(x.key)}">คัดลอก</button>`:''}<br>หมดอายุ ${esc(x.expires_at||'ไม่หมดอายุ')}<br>เวอร์ชันล่าสุด ${esc(x.current_version)}</p>${release?`<section class="release ${release.mandatory?'mandatory':''}"><b>${release.mandatory?'ต้องอัปเดต':'ดาวน์โหลดโปรแกรม'} · v${esc(release.version)}</b><p>${esc(release.release_notes||'ตัวติดตั้งเวอร์ชันล่าสุด')}<br><small>${esc(release.file_name)} · ${size(release.file_size)}<br>SHA-256: <code>${esc(release.sha256)}</code></small></p>${active?`<a class="download-button" href="${esc(release.download_url)}">⬇ ดาวน์โหลดตัวติดตั้ง</a>`:'<p class="muted">ต่ออายุสิทธิ์ก่อนดาวน์โหลด</p>'}</section>`:'<p class="notice">ยังไม่มีตัวติดตั้งเผยแพร่สำหรับโปรแกรมนี้</p>'}<h3>เครื่อง (${x.devices.length}/${x.code==='sms-mix'?1:x.max_devices})</h3>${devices}</article>`;
  }).join('')||'<article class="card">ยังไม่มีโปรแกรมในบัญชีนี้</article>';
  document.querySelectorAll('[data-id]').forEach(b=>b.onclick=async()=>{if(!confirm('ปิดสิทธิ์เครื่องนี้ใช่ไหม?'))return;await fetch('/api/vision7/activate',{method:'DELETE',headers:{'content-type':'application/json'},body:JSON.stringify({device_id:Number(b.dataset.id)})});load()});
  document.querySelectorAll('[data-key]').forEach(b=>b.onclick=async()=>{await navigator.clipboard.writeText(b.dataset.key);b.textContent='คัดลอกแล้ว'});
}
load();
