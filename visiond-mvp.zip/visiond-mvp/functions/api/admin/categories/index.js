import {json,requireAdmin} from '../../../_lib.js';
import {ensureDatabase} from '../../../_schema.js';

export async function onRequestGet(ctx){
  await ensureDatabase(ctx.env);
  const auth=await requireAdmin(ctx);if(auth.error)return auth.error;
  const {results}=await ctx.env.DB.prepare(`SELECT c.*,(SELECT COUNT(*) FROM products p WHERE p.category=c.slug) product_count FROM categories c ORDER BY c.sort_order,c.id`).all();
  return json({items:results});
}

export async function onRequestPost(ctx){
  await ensureDatabase(ctx.env);
  const auth=await requireAdmin(ctx);if(auth.error)return auth.error;
  const body=await ctx.request.json().catch(()=>({}));
  const slug=String(body.slug||'').trim().toLowerCase(),name=String(body.name||'').trim();
  if(!name||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug))return json({error:'กรุณากรอกชื่อและรหัสหมวดภาษาอังกฤษให้ถูกต้อง'},400);
  try{const item=await ctx.env.DB.prepare(`INSERT INTO categories(slug,name,parent_slug,file_type,active,sort_order) VALUES(?,?,?,?,?,?) RETURNING *`).bind(slug,name,String(body.parent_slug||'')||null,String(body.file_type||'PDF'),body.active===false?0:1,Number(body.sort_order)||0).first();return json({item},201)}catch(error){return json({error:String(error).includes('UNIQUE')?'รหัสหมวดนี้ถูกใช้แล้ว':'เพิ่มหมวดไม่สำเร็จ'},400)}
}
