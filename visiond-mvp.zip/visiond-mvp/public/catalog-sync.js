(()=>{
  const grid=document.querySelector('.vd-grid');if(!grid)return;
  const filters=document.createElement('div');filters.className='catalog-category-filters';filters.innerHTML='<button class="active" data-category="all" type="button">ทั้งหมด</button>';grid.before(filters);
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money=n=>new Intl.NumberFormat('th-TH').format((Number(n)||0)/100)+' บาท';
  Promise.all([fetch('/api/products').then(r=>r.ok?r.json():Promise.reject()),fetch('/api/categories').then(r=>r.ok?r.json():{items:[]})]).then(([data,categoryData])=>{
    const products=data.items||[],bySlug=new Map(products.map(p=>[p.slug,p]));
    [...grid.querySelectorAll('.vd-card')].forEach(card=>{const link=card.querySelector('a[href*="slug="]');const slug=link&&new URL(link.href,location.origin).searchParams.get('slug'),product=bySlug.get(slug);card.dataset.category=product?.category||'dinosaur'});
    const existing=new Set([...grid.querySelectorAll('a[href*="slug="]')].map(a=>new URL(a.href,location.origin).searchParams.get('slug')));
    grid.insertAdjacentHTML('beforeend',products.filter(p=>!existing.has(p.slug)).map(p=>`<article class="vd-card" data-category="${esc(p.category)}"><a class="vd-cover" href="/product.html?slug=${encodeURIComponent(p.slug)}"><span class="vd-tag">${esc(p.file_type||'DIGITAL')}</span><span class="vd-ready">พร้อมดาวน์โหลด</span><img src="${esc(p.cover_url||'/assets/product-placeholder.svg')}" alt="${esc(p.title)}"></a><div class="vd-info"><small>VD-${String(p.id).padStart(3,'0')}</small><h2><a href="/product.html?slug=${encodeURIComponent(p.slug)}">${esc(p.title)}</a></h2><p>${esc(p.short_description||p.category_label||'สินค้าดิจิทัล')}</p><div class="vd-bottom"><b>${money(p.price)}</b><a href="/product.html?slug=${encodeURIComponent(p.slug)}">ดูสินค้า</a></div></div></article>`).join(''));
    const used=new Set(products.map(p=>p.category));filters.insertAdjacentHTML('beforeend',(categoryData.items||[]).filter(c=>used.has(c.slug)).map(c=>`<button data-category="${esc(c.slug)}" type="button">${esc(c.name)}</button>`).join(''));
    filters.querySelectorAll('button').forEach(button=>button.onclick=()=>{filters.querySelectorAll('button').forEach(x=>x.classList.toggle('active',x===button));grid.querySelectorAll('.vd-card').forEach(card=>card.hidden=button.dataset.category!=='all'&&card.dataset.category!==button.dataset.category)});
  }).catch(()=>{});
})();
